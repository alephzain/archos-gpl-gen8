
#ifndef DEFAULT_ACOLUMN
#define DEFAULT_ACOLUMN 50	/* default alignment column for results */
#endif				/* (-a switch) */

#ifndef MAX_ARGS
#define MAX_ARGS        32	/* maximum number of args for a function */
#endif

#ifndef DEFAULT_STRLEN
#define DEFAULT_STRLEN  32	/* default maximum # of bytes printed in */
#endif				/* strings (-s switch) */
