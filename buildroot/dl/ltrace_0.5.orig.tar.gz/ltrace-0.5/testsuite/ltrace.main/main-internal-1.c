#include<stdio.h>

void 
display ( char* s )
{
  printf("%s\n",s);
}

